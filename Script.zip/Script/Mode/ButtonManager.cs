using UnityEngine;
using UnityEngine.UI;

public class ButtonManager : MonoBehaviour
{
    [SerializeField] private Button _easyButton;
    [SerializeField] private Button _mediumButton;
    [SerializeField] private Button _hardButton;
    [SerializeField] private Button _superHardButton;
    [SerializeField] private Button _campaignButton;

    private GameModeManager _gameModeManager;

    private void Start()
    {
        _gameModeManager = FindObjectOfType<GameModeManager>();

        _easyButton.onClick.AddListener(() =>
        {
            _gameModeManager.SetGameMode(new EasyMode());
            _gameModeManager.StartCurrentMode();
        });

        _mediumButton.onClick.AddListener(() =>
        {
            _gameModeManager.SetGameMode(new MediumMode());
            _gameModeManager.StartCurrentMode();
        });

        _hardButton.onClick.AddListener(() =>
        {
            _gameModeManager.SetGameMode(new HardMode());
            _gameModeManager.StartCurrentMode();
        });

        _superHardButton.onClick.AddListener(() =>
        {
            _gameModeManager.SetGameMode(new SuperHardMode());
            _gameModeManager.StartCurrentMode();
        });

        _campaignButton.onClick.AddListener(() =>
        {
            _gameModeManager.SetGameMode(new CampaignMode());
            _gameModeManager.StartCurrentMode();
        });
    }
}
