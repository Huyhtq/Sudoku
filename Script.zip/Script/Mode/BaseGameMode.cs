using UnityEngine;

public abstract class BaseGameMode
{
    public abstract void StartGame();
    public virtual int MaxLives => 3;
    public virtual int MaxHints => 3;
}

public class EasyMode : BaseGameMode
{
    public override void StartGame()
    {
        PlayerPrefs.SetString("Difficulty", "Easy");
        PlayerPrefs.SetInt("Level", 1);
        UnityEngine.SceneManagement.SceneManager.LoadScene("GameScene");
    }
}

public class MediumMode : BaseGameMode
{
    public override void StartGame()
    {
        PlayerPrefs.SetString("Difficulty", "Medium");
        PlayerPrefs.SetInt("Level", 1);
        UnityEngine.SceneManagement.SceneManager.LoadScene("GameScene");
    }
}

public class HardMode : BaseGameMode
{
    public override void StartGame()
    {
        PlayerPrefs.SetString("Difficulty", "Hard");
        PlayerPrefs.SetInt("Level", 1);
        UnityEngine.SceneManagement.SceneManager.LoadScene("GameScene");
    }
}

public class SuperHardMode : BaseGameMode
{
    public override void StartGame()
    {
        PlayerPrefs.SetString("Difficulty", "Super Hard");
        PlayerPrefs.SetInt("Level", 1);
        UnityEngine.SceneManagement.SceneManager.LoadScene("GameScene");
    }
}

public class CampaignMode : BaseGameMode
{
    public override void StartGame()
    {
        PlayerPrefs.SetString("Difficulty", "Campaign");
        PlayerPrefs.SetInt("Level", 1);
        PlayerPrefs.SetInt("Lives", MaxLives);
        PlayerPrefs.SetInt("Hints", MaxHints);
        UnityEngine.SceneManagement.SceneManager.LoadScene("GameScene");
    }

    public override int MaxLives => 3;
    public override int MaxHints => 3;
}
