using UnityEngine;

public class GameModeManager : MonoBehaviour
{
    private BaseGameMode _currentMode;

    public void SetGameMode(BaseGameMode mode)
    {
        _currentMode = mode;
    }

    public void StartCurrentMode()
    {
        _currentMode?.StartGame();
    }
}
