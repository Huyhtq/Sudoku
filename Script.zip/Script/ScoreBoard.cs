using TMPro;
using UnityEngine;

public class ScoreBoard : MonoBehaviour
{
    [Header("TextMeshPro Fields")]
    [SerializeField] private TMP_Text[] bestTimeTexts; 
    [SerializeField] private TMP_Text[] playCountTexts; 
    [SerializeField] private TMP_Text[] successTexts; 

    /// <summary>
    /// 
    /// </summary>
    /// <param name="bestTimes"></param>
    /// <param name="playCounts"></param>
    /// <param name="successStats"></param>
    public void UpdateScoreBoard(string[] bestTimes, int[] playCounts, string[] successStats)
    {
        for (int i = 0; i < bestTimeTexts.Length; i++)
        {
            bestTimeTexts[i].text = i < bestTimes.Length ? bestTimes[i] : "-";
        }

        for (int i = 0; i < playCountTexts.Length; i++)
        {
            playCountTexts[i].text = i < playCounts.Length ? playCounts[i].ToString() : "-";
        }

        for (int i = 0; i < successTexts.Length; i++)
        {
            successTexts[i].text = i < successStats.Length ? successStats[i] : "-";
        }
    }
}
