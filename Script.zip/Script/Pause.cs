using UnityEngine;

public class PauseManager : MonoBehaviour
{
    [SerializeField] private Camera mainCamera; 
    [SerializeField] private Camera pauseCamera; 
    [SerializeField] private GameObject pausePanel; 
    private bool isPaused = false;

    private void Start()
    { 
        mainCamera.enabled = true;
        pauseCamera.enabled = false;
        pausePanel.SetActive(false);
    }

    public void TogglePause()
    {
        isPaused = !isPaused;

        if (isPaused)
        {
            mainCamera.enabled = false;
            pauseCamera.enabled = true;
            pausePanel.SetActive(true);
            Time.timeScale = 0f; 
        }
        else
        {
            mainCamera.enabled = true;
            pauseCamera.enabled = false;
            pausePanel.SetActive(false);
            Time.timeScale = 1f; 
        }
    }
}