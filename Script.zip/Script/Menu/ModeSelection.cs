using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

public class ModeSelection : MonoBehaviour
{
    private string mode;
    
    public void OnModeSelected(string mode)
    {      
        PlayerPrefs.SetString("GameMode", mode);

        SceneManager.LoadScene("DoGame");
    }
}
