using TMPro;
using UnityEngine;

public class Hint : MonoBehaviour
{
    [SerializeField] private TMP_Text _hintText;

    private const int GridSize = 9;
    private const int SubGridSize = 3;
    private Cell[,] cells;

    private int _maxHints = 3;  
    private int _remainingHints;  

    /// <summary>
    /// 
    /// </summary>
    public void Initialize(Cell[,] gridCells)
    {
        cells = gridCells;
        _remainingHints = _maxHints;
        UpdateHintUI();
    }

    public void ClearHints()
    {
        _remainingHints = _maxHints;

        UpdateHintUI();

        Debug.Log("Hints cleared.");
    }

    /// <summary>
    /// 
    /// </summary>
    public bool ProvideHint()
    {
        if (cells == null)
        {
            Debug.LogError("Cells array is not initialized! Ensure Initialize() is called.");
            return false;
        }

        if (_remainingHints <= 0)
        {
            Debug.Log("No hints remaining!");
            return false; 
        }

        for (int row = 0; row < GridSize; row++)
        {
            for (int col = 0; col < GridSize; col++)
            {
                if (cells[row, col].Value == 0)
                {
                    int correctValue = FindCorrectValue(row, col);
                    if (correctValue != -1)
                    {
                        Debug.Log($"Hint: Row {row}, Col {col} = {correctValue}");
                        cells[row, col].HighlightHint(correctValue);

                        _remainingHints--;
                        UpdateHintUI();
                        Debug.Log($"Hints remaining: {_remainingHints}");
                        return true;
                    }
                }
            }
        }

        Debug.Log("No hints available. The puzzle might be complete!");
        return false;
    }

    /// <summary>
    /// 
    /// </summary>
    private int FindCorrectValue(int row, int col)
    {
        for (int value = 1; value <= GridSize; value++)
        {
            if (IsValid(row, col, value))
            {
                return value;
            }
        }
        return -1;
    }

    /// <summary>
    /// 
    /// </summary>
    private bool IsValid(int row, int col, int value)
    {
        for (int i = 0; i < GridSize; i++)
        {
            if (cells[row, i].Value == value)
                return false;
        }

        for (int i = 0; i < GridSize; i++)
        {
            if (cells[i, col].Value == value)
                return false;
        }

        int subGridRow = row - row % SubGridSize;
        int subGridCol = col - col % SubGridSize;

        for (int r = subGridRow; r < subGridRow + SubGridSize; r++)
        {
            for (int c = subGridCol; c < subGridCol + SubGridSize; c++)
            {
                if (cells[r, c].Value == value)
                    return false;
            }
        }

        return true;
    }

    /// <summary>
    /// 
    /// </summary>
    public int RemainingHints => _remainingHints;

    /// <summary>
    /// 
    /// </summary>
    public void ResetHints()
    {
        _remainingHints = _maxHints;
    }

    public void HintButton()
    {
        if (ProvideHint()) 
        {
            Debug.Log("Hint given!");
        }
        else
        {
            Debug.Log("Unable to provide a hint.");
        }
    }

    public void SetHints(int hints)
    {
        _remainingHints = hints;
    }

    public int GetHints()
    {
        return _remainingHints;
    }

    private void UpdateHintUI()
    {
        _hintText.text = "Hint: " + GetHints() + "/3";
    }
}
